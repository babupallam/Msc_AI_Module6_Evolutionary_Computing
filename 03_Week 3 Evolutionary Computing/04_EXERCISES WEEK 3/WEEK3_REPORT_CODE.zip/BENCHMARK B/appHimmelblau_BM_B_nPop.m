%% DE /rand/1/bin
clc; clear;

%% Problem Definition

problem.CostFunction = @(x,y) HimmelblauFunction(x,y);    % Cost Function
problem.nVar = 2;              % Number of Decision Variables
problem.VarMin = -5;            % Lower Bound of Decision Variables
problem.VarMax = 5;             % Upper Bound of Decision Variables
problem.toleranceValue = 10^-5; % tolerance value at which the solution is acceptable with the maximum error possible

%% DE Parameters
params.MaxIt = 1000;       % Maximum Number of Iterations
params.beta_min = 0.2;     % Lower Bound of Scaling Factor (0)
params.beta_max = 0.8;     % Upper Bound of Scaling Factor (2)
params.pCR = 0.2;          % Crossover Probability
%% Calling DE for different nPop values to see the effect of it in the Result
%different number of 'nPop' values
nPopVariation = [5,10,100,500,1000,2000,5000,10000];

%Variable to store the number of Iterations take to reach the tolerance
%value
numberOfIterations = numel(nPopVariation);
%repeat the test for numberOfIterations times
for i=1:numberOfIterations
    %Assign value to nPop
    params.nPop = nPopVariation(i);
    out= DE(problem, params);
    % plot the result into the existing graph else create a new graph
    hold on
    semilogy(out.BestCost,"LineWidth",2);
    hold off
end

% Describing the attributes for the graph
title("Effect of Population Size (nPop")
xlabel('Iterations');
ylabel('Best Cost');
%for the purpous of seeing the change in each experiment, xlim is used to
%get a more close view
ylim([0 10^-4])
xlim([0 200]);
%draw a line parallel to x axis to find on which iteration the output
%reaches to tolerance value
yline(problem.toleranceValue,'-',{'Acceptable','Limit'});
grid on;
legend(num2str(nPopVariation.'), 'location', 'northeast');
