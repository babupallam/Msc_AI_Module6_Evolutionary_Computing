if any(it == genNumber(:))
        %this line of code below is to  make sure that all graphs come into
        %seperate
        figure(it);
        % plot the contour graph
        %create mesh
        [X,Y] = meshgrid(VarMin:0.1:VarMax, VarMin:0.1:VarMax);
        %create the possible solution space with X and Y 
        Z = (X.^2 + Y - 11).^2 + (X + Y.^2 - 7).^2;
        %draw contour
        colormap(bone)
        contour(X,Y,Z);
        
        %mark the points in the contour graph for the iteration 'it'
        for loop = 1:nPop
            hold on;
            scatter(plotX(it,loop),plotY(it,loop),"filled","k" );
            title(['Himmelblau Function' num2str(it) "th Generation"]);
            hold on
            scatter(BestSol.Position(1), BestSol.Position(2),"filled","o","r");
            hold off
        end
    end
