function f = Sphere(x1, x2)

f = x1.^2 + x2.^2;
