% Clear Figure
hold on

% Prepare Mesh for Contour Plots
x1 = linspace(VarMin(1),VarMax(1));
x2 = linspace(VarMin(end),VarMax(end));
[X1,X2] = meshgrid(x1,x2);

% Contour Plot of Constraints (Shaded Region is Infeasible)
C = Constraints(X1, X2, R);
contourf(X1, X2, C, [eps eps], 'b');

% Contour Plot of Cost Function
Z = CostFunction(X1,X2);
colormap(bone)
contour(X1, X2, log(Z), 5);

% Plot whole Population as red stars
for i = 1:nPop
    plot(pop(i).Position(1), pop(i).Position(2), 'r*')
end

axis equal