function z = RosenBrockFunction(x,y)
        %based on 5a slide no 12
     z =100*(y-x.^2).^2+(1-x).^2;
end