clear; clc;
clear;

%% Problem Definition
problem.CostFunction = @(x) MinOne(x);
problem.nVar = 100;

%% GA Parameters
params.MaxIt = 100;
params.nPop = 200;

params.beta = 1;
params.pC = 1;
params.mu = 0;


%% BINARY GA for a single time exicution from the original code
% out = RunGA(problem, params);

%% Results
% % semilogy(out.bestcost, 'LineWidth', 2);
% plot(out.bestcost,"LineWidth",2)
% xlabel('Iterations');
% ylabel('Best Cost');
% grid on;

%% %% BINARY GA for 30 exicutions in a sequence

%Variable to store the number of Iterations take to reach the minimum
%value (In Min One Problem, it is zero)
iterationsInEachSolution = [];

%Inorder to find the median value of the number of iterations needed,
%Run the same Binary GA 30 times
for i=1:30
    out(i) = RunGA(problem, params); 
    %filter number of non zeros, since adding one to this will give the
    %minimum iterations needed for the result
    iterationsInEachSolution(i)= nnz(out(i).bestcost)+1;
    hold on
    plot(out(i).bestcost,"LineWidth",2)
    hold off
end

%Calculate Median value
medianOfAllSolutions = median(iterationsInEachSolution)

%plot median value in the graph
hold on
plot(medianOfAllSolutions,0,"r*","MarkerSize",20)
hold off

xlabel('Iterations');
ylabel('Best Cost');
grid on;