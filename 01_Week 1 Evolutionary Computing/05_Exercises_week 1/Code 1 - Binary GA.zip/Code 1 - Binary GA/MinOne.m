function z = MinOne(x)

    z = sum(x);

end
