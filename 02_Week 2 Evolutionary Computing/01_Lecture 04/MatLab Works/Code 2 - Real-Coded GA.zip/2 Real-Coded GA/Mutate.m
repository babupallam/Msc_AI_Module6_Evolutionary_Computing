function o = Mutate(p, mu, sigma)

    flag = (rand(size(p)) < mu);

    o = p;
    r = randn(size(p));
    o(flag) = p(flag) + sigma*r(flag);
    
end