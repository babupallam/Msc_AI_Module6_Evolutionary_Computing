clc; clear;

%% Problem Definiton

CostFunction = @(x,y) RF(x,y);  % Cost Function
VarSize =2;
nVar = 5;       % Number of Unknown (Decision) Variables
VarMin =  -10;  % Lower Bound of Decision Variables
VarMax =  10;   % Upper Bound of Decision Variables


%% Parameters of PSO

MaxIt = 1000;        % Maximum Number of Iterations
nPop = 50;           % Population Size (Swarm Size)
w = 1;               % Intertia Coefficient
wdamp = 0.99;        % Damping Ratio of Inertia Coefficient
c1 = 2;              % Personal Acceleration Coefficient
c2 = 2;              % Social Acceleration Coefficient
pausing = 1;        % If set to 1 (true), pause execution before next iteration until a key is pressed


MaxVelocity = 0.2*(VarMax-VarMin);
MinVelocity = -MaxVelocity;
%% Initialization

% The Particle Template
empty_particle.Position = [];
empty_particle.Velocity = [];
empty_particle.Cost = [];
empty_particle.Best.Position = [];
empty_particle.Best.Cost = [];

% Create Population Array
particle = repmat(empty_particle, nPop, 1);

% Initialize Global Best
GlobalBest.Cost = inf;

% Initialize Population Members
for i=1:nPop

    % Generate Random Solution
    particle(i).Position = unifrnd(VarMin, VarMax, VarSize);

    % Initialize Velocity
    particle(i).Velocity = zeros(VarSize);

    % Evaluation
    particle(i).Cost = CostFunction(particle(i).Position(1),particle(i).Position(2));

    % Update the Personal Best
    particle(i).Best.Position = particle(i).Position;
    particle(i).Best.Cost = particle(i).Cost;

    % Update Global Best
    if particle(i).Best.Cost < GlobalBest.Cost
        GlobalBest = particle(i).Best;
    end

end

% Array to Hold Best Cost Value on Each Iteration
BestCosts = zeros(MaxIt, 1);




%% Main Loop of PSO

for it=1:MaxIt

    for i=1:nPop

        % Update Velocity
        particle(i).Velocity = w*particle(i).Velocity ...
            + c1*rand(VarSize).*(particle(i).Best.Position - particle(i).Position) ...
            + c2*rand(VarSize).*(GlobalBest.Position - particle(i).Position);

        % Apply Velocity Limits
        particle(i).Velocity = max(particle(i).Velocity, MinVelocity);
        particle(i).Velocity = min(particle(i).Velocity, MaxVelocity);

        % Update Position
        particle(i).Position = particle(i).Position + particle(i).Velocity;

        % Apply Lower and Upper Bound Limits
        particle(i).Position = max(particle(i).Position, VarMin);
        particle(i).Position = min(particle(i).Position, VarMax);

        % Evaluation
        particle(i).Cost = CostFunction(particle(i).Position(1),particle(i).Position(2));

        % Update Personal Best
        if particle(i).Cost < particle(i).Best.Cost

            particle(i).Best.Position = particle(i).Position;
            particle(i).Best.Cost = particle(i).Cost;

            % Update Global Best
            if particle(i).Best.Cost < GlobalBest.Cost
                GlobalBest = particle(i).Best;
            end

        end

    end

    % Store the Best Cost Value
    BestCosts(it) = GlobalBest.Cost;

    disp(['Iteration ' num2str(it) ': Best Cost = ' num2str(BestCosts(it))]);

    % Damping Inertia Coefficient
    w = w * wdamp;
    % Pause execution before next iteration until a key is pressed
    if pausing
        clf;
        Draw;
        pause;
    end

end
%% Show Results

% Display Best Solution in Command Window
disp(BestSol)
x = BestSol.Position;

% First Subplot (Contour)
% subplot(2,1,1);
Draw

% % Second Subplot (Performance)
% subplot(2,1,2);
%
% % Best Cost vs Iteration - Performance Graph
% semilogy(BestCost, 'LineWidth', 2);
% xlabel('Iteration');
% ylabel('Best Cost');
% grid on;

% Give focus to Command Window
pause(0.05);
commandwindow;
